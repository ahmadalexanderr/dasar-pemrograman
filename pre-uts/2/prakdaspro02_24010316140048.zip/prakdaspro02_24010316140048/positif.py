# Nama file: positif.py
# Pembuat : Ahmad Alexander
# Tanggal 2 September 2019

# Definisi dan spesifikasi
# IsPositif? : integer --> boolean
# IsPositif? (x) benar jika x positif

# Realisasi
def IsPositif(x):
    return x >= 0


# Aplikasi
print(IsPositif(1))
print(IsPositif(0))
print(IsPositif(-1))
