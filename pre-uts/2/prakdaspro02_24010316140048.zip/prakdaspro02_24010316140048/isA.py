# Nama file: positif.py
# Pembuat : Ahmad Alexander
# Tanggal 2 September 2019

# Definisi dan Spesifikasi
# IsAnA : character --> boolean
# IsAnA(C) benar jika c adalah karakter (huruf) 'A'

# Realisasi
def IsAnA(c):
    return c == "A"


# Aplikasi
print(IsAnA(1))
print(IsAnA(0))
print(IsAnA(-1))
